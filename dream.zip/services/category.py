from sqlalchemy.orm import Session

from models.category import Category
from schemas.category import CategoryCreate
from repositories.category import (
    create_category,
    get_category_by_id,
    get_categories,
)


def create_category_service(db: Session, category: CategoryCreate):
    new_category = Category(name=category.name)

    return create_category(db, new_category)


def get_category_by_id_service(db: Session, category_id: int):
    return get_category_by_id(db, category_id)


def get_categories_service(db: Session):
    return get_categories(db)

from sqlalchemy.orm import Session

from models.user import User
from schemas.user import UserCreate
from repositories.user import create_user, get_user_by_id, get_users


def create_user_service(db: Session, user: UserCreate):
    new_user = User(name=user.name, email=user.email, password=user.password)

    return create_user(db, new_user)


def get_user_by_id_service(db: Session, user_id: int):
    return get_user_by_id(db, user_id)


def get_users_service(db: Session):
    return get_users(db)

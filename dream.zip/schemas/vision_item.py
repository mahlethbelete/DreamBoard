from datetime import datetime

from pydantic import BaseModel, Field


class VisionItemCreate(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    description: str | None = None
    image_url: str | None = None
    target_date: datetime | None = None
    category_id: int
    status: str = "not_started"


class VisionItemResponse(BaseModel):
    id: int
    user_id: int
    category_id: int
    title: str
    description: str | None
    image_url: str | None
    target_date: datetime | None
    status: str
    created_at: datetime

    class Config:
        from_attributes = True